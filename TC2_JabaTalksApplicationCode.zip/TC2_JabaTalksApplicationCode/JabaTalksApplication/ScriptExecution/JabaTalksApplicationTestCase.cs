﻿using ActiveUp.Net.Mail;
using JabaTalksApplication.ApplicationFunctions;
using JabaTalksApplication.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JabaTalksApplication.ScriptExecution
{
    [TestFixture]
    public class JabaTalksApplicationTestCase:BaseClass
    {      
               
        SignInPage signinpage = new SignInPage();
        public SignUpPage signuppage;
        ReadMail readmail = new ReadMail();

        [Test, Order(1)]
        public void CheckValuesUnderLanguage()
        {
            try
            {
                signinpage.CheckValues(driver);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        [Test,Order(2)]        
         public void RegisterUser()
         {
            try
            {
                signuppage=signinpage.Register(driver);
                signuppage.GetStarted();                
            }
             catch(Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
         }
        

        [Test, Order(3)]
        public void VerifyMail()
        {
            try
            {
                signuppage = signinpage.Register(driver);
                signuppage.GetStarted();
                readmail.GetAllEmails();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }


    }
}
