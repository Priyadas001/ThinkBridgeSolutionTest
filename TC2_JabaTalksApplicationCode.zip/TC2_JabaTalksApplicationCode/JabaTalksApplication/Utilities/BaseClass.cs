﻿using JabaTalksApplication.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace JabaTalksApplication.ScriptExecution
{
    [TestFixture]
    public class BaseClass
    {
        public IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            Browser.InitializeDriver();
            driver = Browser.driver;
        }

        [TearDown]
        public void Close()
        {
            driver.Quit();
        }
    }
}
