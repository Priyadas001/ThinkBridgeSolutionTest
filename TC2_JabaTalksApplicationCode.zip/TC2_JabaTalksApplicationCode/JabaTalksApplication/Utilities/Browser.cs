﻿using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
using System.Collections.Generic;
using System.Text;

namespace JabaTalksApplication.Utilities
{
    public static class Browser
    {
        public static IWebDriver driver = null;
        private static string browser, URL;


        public static void InitializeDriver()
        {
            try
            {
                var config = new ConfigurationBuilder().AddJsonFile("App-config.json").Build();
                browser = config["browser"];
                URL = config["url"];

                switch (browser)
                {
                    case "Chrome":                        
                        ChromeOptions options = new ChromeOptions();
                        //options.AddArgument("headless");
                        //options.AddArgument("--profile-directory=Default");
                        driver = new ChromeDriver(".", options);
                        driver.Manage().Cookies.DeleteAllCookies();
                        break;
                    case "IE":
                        driver = new InternetExplorerDriver(".");
                        break;
                    case "Firefox":
                        driver = new FirefoxDriver(".");
                        break;
                }
                LaunchURL(URL);
            }
            catch (Exception e)
            {
                e.Message.ToString();
                throw;
            }
        }

        public static IWebDriver LaunchURL(string URL)
        {
            try
            {
                driver.Manage().Window.Maximize();
                driver.Navigate().GoToUrl(URL);
                return driver;
            }
            catch (Exception e)
            {
                e.Message.ToString();
                throw;
            }
        }
    }
}
