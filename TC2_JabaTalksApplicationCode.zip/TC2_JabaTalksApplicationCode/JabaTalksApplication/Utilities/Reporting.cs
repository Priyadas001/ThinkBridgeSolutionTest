﻿using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace JabaTalksApplication.Utilities
{
    public class Reporting
    {
        public AventStack.ExtentReports.ExtentReports extent = null;

        [OneTimeSetUp]
        public void ExtentStart()
        {
            extent = new AventStack.ExtentReports.ExtentReports();

            var reporter = new ExtentHtmlReporter(@"C:\dgyey");
            reporter.Config.DocumentTitle = "Automation Testing Report";
            reporter.Config.ReportName = "Vindati Testing";
            reporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Standard;
            extent.AttachReporter(reporter);
            extent.AddSystemInfo("Environment", "Demo");
            extent.AddSystemInfo("Machine", Environment.MachineName);
            extent.AddSystemInfo("OS", Environment.OSVersion.VersionString);

        }
        [OneTimeTearDown]
        public void ExtentClose()
        {
            extent.Flush();
        }
    }
}
