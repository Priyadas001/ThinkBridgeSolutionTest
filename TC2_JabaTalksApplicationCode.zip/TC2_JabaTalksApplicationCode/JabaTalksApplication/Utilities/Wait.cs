﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace JabaTalksApplication.Utilities
{
    public static class Wait
    {        

        //waiting for page to load
        public static void WaitForFinishLoading(IWebDriver webDriver)
        {
            try
            {
                IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(webDriver, TimeSpan.FromMilliseconds(30000));
                wait.Until(driver1 => ((IJavaScriptExecutor)webDriver).ExecuteScript("return document.readyState").Equals("complete"));
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                throw ex;
            }
        }

        
        //Wait for finding element
        public static IWebElement WaitAndFindElement(this IWebDriver webDriver, By locator, string waitingMethod, int timeSpan = 30000)
        {
            IWebElement element = null;
            WaitForFinishLoading(webDriver);
            try
            {
                WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromMilliseconds(timeSpan));

                if (waitingMethod.ToString().Equals("exists", StringComparison.InvariantCultureIgnoreCase))
                {
                    element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(locator));
                }
                else if (waitingMethod.ToString().Equals("visible", StringComparison.InvariantCultureIgnoreCase))
                {
                    element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(locator));
                }
                else if (waitingMethod.ToString().Equals("clickable", StringComparison.InvariantCultureIgnoreCase))
                {
                    element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(locator));
                }
                return element;
            }
            catch (NoSuchElementException)
            {
                Wait.WaitForFinishLoading(webDriver);
                element = WaitAndFindElement(webDriver, locator, waitingMethod);
                return element;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }


    }
}
