﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Text;

namespace JabaTalksApplication.Utilities
{
    public class StepExecutors
    {
        //Send Text
        public static void SendText(IWebDriver driver, By locator, string text)
        {
            IWebElement element = null;
            Wait.WaitForFinishLoading(driver);
            try
            {
                element = Wait.WaitAndFindElement(driver, locator, "clickable");
                element.Clear();
                element.Click();
                element.SendKeys(text);                
            }
            catch (ElementClickInterceptedException)
            {
                Wait.WaitForFinishLoading(driver);
                element = Wait.WaitAndFindElement(driver, locator, "clickable");
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", element);
            }
            catch (StaleElementReferenceException)
            {
                Wait.WaitForFinishLoading(driver);
                element = Wait.WaitAndFindElement(driver, locator, "exists");
                element.Click();
            }
            catch (Exception ex)
            {               
                Console.WriteLine(ex.Message.ToString());
                throw ex;
            }
        }
        


        //Click Element 
        public static void ClickElement(IWebDriver driver, By locator)
        {
            IWebElement element = null;
            Wait.WaitForFinishLoading(driver);
            try
            {
                element = Wait.WaitAndFindElement(driver, locator, "clickable");
                element.Click();                
            }
            catch (ElementClickInterceptedException)
            {
                ClickElementUsingJS(driver, locator);
            }
            catch (StaleElementReferenceException)
            {
                Wait.WaitForFinishLoading(driver);
                element = Wait.WaitAndFindElement(driver, locator, "exists");
                element.Click();                
            }
            catch (Exception ex)
            {             
                Console.WriteLine(ex.Message.ToString());
                throw;
            }
        }

        //Double Click Button using Action Class
        public static void DoubleClick(IWebDriver driver, By locator)
        {
            Wait.WaitForFinishLoading(driver);
            IWebElement btnElement = driver.FindElement(locator);
            Actions actions = new Actions(driver);
            actions.DoubleClick(btnElement).Perform();
        }

        //Click Element using JavaScript
        public static void ClickElementUsingJS(IWebDriver driver, By locator)
        {
            IWebElement element = null;
            try
            {
                Wait.WaitForFinishLoading(driver);
                element = Wait.WaitAndFindElement(driver, locator, "clickable");
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", element);
                
            }
            catch (Exception ex)
            {                
                Console.WriteLine(ex.Message.ToString());
                throw;
            }
        }
    }
}
