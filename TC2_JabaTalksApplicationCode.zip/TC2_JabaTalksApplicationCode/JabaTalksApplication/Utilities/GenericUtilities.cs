﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

namespace JabaTalksApplication.Utilities
{
    public static class GenericUtilities
    {
        public static void TakeScreenshot(string filename, IWebDriver webDriver, [CallerMemberName]String methodName=null)
        {
            var screenshotDriver = webDriver as ITakesScreenshot;
            var screenshot = screenshotDriver.GetScreenshot();
            string DirectoryPath = AppDomain.CurrentDomain.BaseDirectory;
            string[] binPath = DirectoryPath.Split("bin");
            string ProjectPath = binPath[0];
            string FilePath = "/TestLogs";
            string currentDateTime = DateTime.Now.ToString("dd_MM_yyyy").ToString() + "/TestScreenshots";
            if (!Directory.Exists(ProjectPath + FilePath + "/" + currentDateTime))
            {
                Directory.CreateDirectory(ProjectPath + FilePath + "/" + currentDateTime);
            }
            var fullFilename = System.IO.Path.Combine(ProjectPath + FilePath + "/" + currentDateTime, filename + "_" + methodName + "_" + DateTime.Now.ToString("HHmmss-yyyyMMdd") + ".png");
            try
            {
                TestContext.WriteLine($"Writing screenshot: {fullFilename}");
                screenshot.SaveAsFile(fullFilename, ScreenshotImageFormat.Png);
                TestContext.AddTestAttachment(fullFilename);
            }
            catch (Exception)
            {
                TestContext.WriteLine($"Unable to write screenshot: {fullFilename}");
            }
        }
    }
}
