﻿using JabaTalksApplication.Utilities;
using JabaTalksApplication.ApplicationFunctions;
using Microsoft.Extensions.Configuration;
using NuGet.Frameworks;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace JabaTalksApplication.ApplicationFunctions
{
    public class SignInPage
    {
        public IWebDriver driver;

        /********Xpath Sign in Page************************/
        private readonly By txt_Username = By.Name("email");
        private readonly By txt_Password = By.Name("password");
        private readonly By link_Register = By.XPath("//a[contains(.,'Register')]");        
        private readonly By dropdown_languagevalue = By.XPath("//li[@class='ui-select-choices-group']/descendant::div/descendant::div");
        private readonly By dropdown_language = By.CssSelector("[placeholder='Choose Language']");

        /**************Extract value from Config File*************/
        public static IConfiguration config = new ConfigurationBuilder().AddJsonFile("App-config.json").Build();

        public SignUpPage Register(IWebDriver driver)
        {
            try
            {
                StepExecutors.SendText(driver, txt_Username, config["username"].ToString());
                StepExecutors.SendText(driver, txt_Password, config["password"].ToString());
                StepExecutors.ClickElement(driver, link_Register);
            }
            catch (Exception ex)
            {
                GenericUtilities.TakeScreenshot("In Registration function", driver);
                Console.WriteLine(ex.Message.ToString());
                Assert.Fail();
                throw;
            }
            return new SignUpPage(driver);
        }

        public void CheckValues(IWebDriver driver)
        {
            try
            {
                StepExecutors.ClickElement(driver, dropdown_language);
                IList<IWebElement> all = driver.FindElements(dropdown_languagevalue);
                int i = 0;
                String[] allText = new String[all.Count];             
                
                foreach(IWebElement element in all)
                {
                     allText[i] = element.Text;                    
                    if (allText[i].Contains("English") || allText[i].Contains("Dutch"))
                    {
                        Console.WriteLine(allText[i]);
                    }
                    else
                    {
                        Assert.Fail();
                    }
                    i++;
                }              
             
            }
            catch(Exception ex)
            {
                GenericUtilities.TakeScreenshot("Check values under Language function", driver);
                Console.WriteLine(ex.Message.ToString());
                Assert.Fail();
                throw;
            }
        }

    }
}
