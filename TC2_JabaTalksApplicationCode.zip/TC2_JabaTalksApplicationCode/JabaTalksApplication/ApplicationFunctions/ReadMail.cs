﻿using ActiveUp.Net.Mail;
using JabaTalksApplication.Utilities;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace JabaTalksApplication.ApplicationFunctions
{
    public class ReadMail
    {
        public static IConfiguration config = new ConfigurationBuilder().AddJsonFile("App-config.json").Build();
        public void GetAllEmails()
        {
            try
            {
                var mailRepository = new VerifyMail(config["mailServer"].ToString(),
                                993, true,
                                config["username"].ToString(), config["password"].ToString());

                var emailList = mailRepository.GetAllMails("inbox", "JabaTalks");

                foreach (Message email in emailList)
                {
                    Console.WriteLine("<p>{0}: {1}</p><p>{2}</p>", email.From, email.Subject, email.BodyHtml.Text);
                    if (email.Attachments.Count > 0)
                    {
                        foreach (MimePart attachment in email.Attachments)
                        {
                            Console.WriteLine("<p>Attachment: {0} {1}</p>", attachment.ContentName, attachment.ContentType.MimeType);
                        }
                    }
                }
            }
            catch(Exception ex)
            {                
                Console.WriteLine(ex.Message.ToString());
                Assert.Fail();
                throw;
            }
        }
    }
}
