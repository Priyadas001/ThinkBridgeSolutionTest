﻿using JabaTalksApplication.Utilities;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace JabaTalksApplication.ApplicationFunctions
{
    public class SignUpPage
    {
        public IWebDriver driver;

        /**************Define Xpath here*************/
        private readonly By txt_FullName = By.Name("name");
        private readonly By txt_Organization = By.Id("orgName");
        private readonly By txt_Email = By.Name("email");
        private readonly By chk_Terms = By.XPath("//span[contains(.,'I agree to the')]");
        private readonly By btn_GetStarted = By.XPath("//button[contains(.,'Get Started')]");


        /**************Extract value from Config File*************/
        public static IConfiguration config = new ConfigurationBuilder().AddJsonFile("App-config.json").Build();

        public SignUpPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void GetStarted()
        {
            try
            {                
                StepExecutors.SendText(driver, txt_FullName, config["fullname"].ToString());
                StepExecutors.SendText(driver, txt_Organization, config["org"].ToString());
                StepExecutors.SendText(driver, txt_Email, config["email"].ToString());                
                StepExecutors.ClickElement(driver, chk_Terms);
                StepExecutors.ClickElement(driver, btn_GetStarted);                
            }
            catch (Exception ex)
            {
                GenericUtilities.TakeScreenshot("Get Started Function",driver);
                Console.WriteLine(ex.Message.ToString());
                Assert.Fail();
                throw;
            }            
        }

    }
}
